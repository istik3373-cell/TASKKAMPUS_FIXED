TaskKampus Demo
1. Buka folder di VS Code
2. Jalankan index.html menggunakan Live Server
3. Navigasi sidebar sudah aktif
